#!/bin/sh
docker exec -t -i fuglu-develop /bin/bash
