#!/bin/sh
/usr/local/bin/smtp-source -c -s 30 -m 10000 127.0.0.1:10025
