#!/bin/sh
#build initial fuglu docker (using the current git master)
docker build -t fuglu-develop dockerfuglu
