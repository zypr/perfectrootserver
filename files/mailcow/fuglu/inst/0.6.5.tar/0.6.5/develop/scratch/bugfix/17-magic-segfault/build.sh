#!/bin/sh
sudo docker build -t bug17 debianenv
