#!/bin/bash
sudo docker run -p 10025:10025 bug17
