fail2ban.client.fail2banreader module
=====================================

.. automodule:: fail2ban.client.fail2banreader
    :members:
    :undoc-members:
    :show-inheritance:
